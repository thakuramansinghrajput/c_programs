#include<stdio.h>
int  main()
{
    int l,b,area;
    l=10;
    b=6;
    area=l*b;
    printf("area of rectangle is %d",area);
    return 0;
}