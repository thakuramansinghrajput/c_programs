#include<stdio.h>
int main()
{
    float p,r,t,si;
    p=1200;
    t=2;
    r=5.4;
    si=(p*r*t)/100;
    printf("%f",si);
    
    return 0;
    
}