#include<stdio.h>
int main()
{
    float a,b,c,d,e,average,total,percentage;
    a=90;
    b=50;
    c=70;
    d=33;
    e=99;
    total=a+b+c+d+e;
    average=(a+b+c+d+e)/5;
    percentage=(a+b+c+d+e)/500*100;
    printf("\n%f \n%f \n%f",total,average,percentage);
    
}