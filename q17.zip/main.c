#include<stdio.h>
int main()
{
    int l,b,perimeter;
    l=10;
    b=6;
    perimeter=2*(l+b);
    printf("the perimeter of rectangle is %d",perimeter);
    return 0;
    
}