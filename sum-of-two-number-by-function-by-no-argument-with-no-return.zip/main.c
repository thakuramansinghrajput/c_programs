// create a function to sum the two numbers //
// by no argument with no return //

#include<stdio.h>
void sum()
{
    int c,a,b;
    scanf("%d%d",&a,&b);
    c = a+b;
    printf("%d",c);
    
}

int main()
{
    int s;
    sum();
    
    return 0;
}