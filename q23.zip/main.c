#include<stdio.h>
int main()
{
    int year,month,week,day;
    day=365;
    year=day/365;
    month=day/30;
    week=day/7;
    printf("\n%d\n%d\n%d",year,month,week);
    return 0;
    
}