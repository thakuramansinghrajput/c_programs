#include <stdio.h>
#include<string.h>
int main()
{
    char x[100];
    int length ;
    gets(x);
    length = strlen(x);
    printf("%d",length);
        
        return 0;
}