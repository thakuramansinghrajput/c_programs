#include<stdio.h>
int main()
{
    int n_students = 3;
    int n_subjects = 5;
    
    int marks[3][5];
    
    for(int i=0; i<n_students; i++){
        for(int j=0; j<n_subjects; j++){
        printf("The marks of student %d in %d subjects\n",i,j);
        scanf("%d",&marks[i][j]);
        }
    }
    
    for(int i=0; i<n_students; i++){
        for(int j=0; j<n_subjects; j++){
        printf("The marks of student %d in %d subjects is %d\n",i,j,marks[i][j]);
    }
    }
    return 0;
}