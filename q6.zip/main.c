#include<stdio.h>
int main()
{
    int dividend,divisor,quotient,remainder;
    dividend=25;
    divisor=4;
    quotient=dividend/divisor;
    remainder=dividend%divisor;
    printf("quotient is %d",quotient);
    printf("remainder is %d\n", remainder);
    return 0;
}