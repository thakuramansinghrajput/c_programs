#include <stdio.h>
#include<string.h>
int main()
{
    char x[100];
    int length ;
    gets(x);
    
    for(int i = 0; x[i] != '\0'; i++)
    {
        if(x[i]>=65 && x[i]<=97)
        {
        x[i] = x[i]+32;
        }
        else if(x[i]>=97 && x[i]<=122)
            
        x[i] = x[i]-32;
        
        else
        x[i] = x[i];
        
        
        printf("%c\t", x[i]);
        
            
        }
        
        
    }
    return 0;
    
}