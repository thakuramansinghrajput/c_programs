#include<stdio.h>
int main()
{
    float a,area;
    a=15;
    area=(1.73*a*a)/4;
    printf("area of equilateral traingle is %f",area);
    return 0;
    
}