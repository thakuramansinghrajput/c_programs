#include<stdio.h>
int main()
{
    float a,squareroot;
    a=10;
    squareroot=sqrt(a);
    printf("the square root is %f",squareroot);
    return 0;
}