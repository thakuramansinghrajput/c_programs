#include<stdio.h>
int main()
{
    printf("the sales total is : $172.53");
    return 0;
    
}
