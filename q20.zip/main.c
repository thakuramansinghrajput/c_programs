#include<stdio.h>
int main()
{
    float cm,m,km;
    m=1;
    cm=m*100;
    km=m/1000;
    printf("\n%f\n%f",cm,km);
    return 0;
    
}