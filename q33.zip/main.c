#include<stdio.h>
int main()
{
    long int num;
    num=9621376060;
    printf("%ld",num);
    return 0;
    
}