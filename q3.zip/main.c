#include <stdio.h>
int main()
{
    int x,y,sum;
    x=10;
    y=20;
    sum=x+y;
    printf("the sum of two number is %d",sum);

    return 0;
}
