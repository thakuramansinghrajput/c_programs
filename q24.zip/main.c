#include<stdio.h>
int main()
{
    int x,y,value;
    x=2;
    y=5;
    value=pow((x),y);
    printf("%d",value);
    return 0;
}
