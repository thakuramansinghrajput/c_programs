#include<stdio.h>
void goodmoring();
void goodafternoon();
void goodnight();

int main()
{
    goodmoring();
    goodafternoon();
    goodnight();
    return 0;
}

void goodmoring(){
    printf("goodmoring ammu\n");
}    
void goodafternoon(){
    printf("goodafternoon ammu\n");
}
void goodnight(){
    printf("goodnight ammu\n");
}



