// create a function to sum the two numbers //
// by argument with no return //

#include<stdio.h>
void sum(int a,int b)
{
    int c;
    c = a+b;
    printf("%d",c);
}

int main()
{
    int x,y;
    printf("Enter the number\n");
    scanf("%d%d",&x,&y);
    sum(x,y);
    return 0;
}
   