#include<stdio.h>
int main()
{
    int marks[4];
    int *ptr;
    ptr = &marks[0];
    
    for(int i = 0; i<4; i++){
        printf("The marks of student %d is :\n",i);
        scanf("%d",ptr);
        ptr++;
    }
    
    
    for(int i = 0; i<4; i++){
        printf("The value of %d student  is %d\n",i ,marks[i]);
      
        
    }
}