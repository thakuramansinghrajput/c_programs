#include<stdio.h>
int main()
{
    int a,b,c;
    a=50;
    b=100;
    c=180-(a+b);
    printf("%d",c);
    return 0;
    
}