#include<stdio.h>
int main()
{
    int a,b,sum,substract,multiply,divide;
    a=10;
    b=5;
    sum=a+b;
    substract=a-b;
    multiply=a*b;
    divide=a/b;
    printf("\n%d\n%d\n%d\n%d",sum,substract,multiply,divide);
    return 0;
    
}