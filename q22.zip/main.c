#include<stdio.h>
int main()
{
    float f,c;
    f=100.2;
    c=(f-32)*5/9;
    printf("%f",c);
    return 0;
    
}