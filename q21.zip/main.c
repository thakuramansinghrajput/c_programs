#include<stdio.h>
int main()
{
  float f,c;
  c=10.1;
  f=(c*9/5)+32;
  printf("%f",f);
  return 0;
  
}