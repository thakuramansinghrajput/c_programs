#include<stdio.h>
int main()
{
    int marks[] = {100, 55, 66};
    
    printf("The marks of student 1 is %d\n", marks[0]);
    printf("The marks of student 2 is %d\n", marks[1]);
    printf("The marks of student 3 is %d\n", marks[2]);
return 0;
}