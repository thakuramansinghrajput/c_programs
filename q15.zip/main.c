#include<stdio.h>
int main()
{
 int a,b,sum;
 a=5;
 b=6;
 sum=a+b;
 printf("the sum of %d",sum);
 return 0;
}