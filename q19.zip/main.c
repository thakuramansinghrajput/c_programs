#include<stdio.h>
int  main()
{
    float pie,r,circumference,daimeter,area;
    pie=3.14;
    r=6;
    circumference=2*pie*r;
    daimeter=2*r;
    area=pie*r*r;
    printf("\n%f\n%f\n%f",circumference,daimeter,area);
    return 0;
}