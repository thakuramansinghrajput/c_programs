#include<stdio.h>
int main()
{
    float radius,pie,volume;
    radius=48;
    pie=3.14;
    volume=4/3*pie*(radius*radius*radius);
    printf("the volume of sphere is %f",volume);
    return 0;
}