#include<stdio.h>
int main()
{
    float x,y,product;
    x=1.9;
    y=2.4;
    product=x*y;
    printf("the product of the float is %f",product);
    
    return 0;
}
    


