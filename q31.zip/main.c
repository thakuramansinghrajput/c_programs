#include<stdio.h>
int main()
{
    float p,r,t,ci;
    p=1200;
    t=2;
    r=5.4;
    ci=p*(pow((1+r/100),t));
    printf("%f",ci);
    
    return 0;
    
}