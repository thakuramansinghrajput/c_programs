#include<stdio.h>
int main()
{
    float a,b,c,s,area;
    s=0;
    area=0;
    a=6;
    b=4;
    c=5;
    s=(a+b+c)/2;
    area=sqrt(s*(s-a)*(s-b)*(s-c));
    
    printf("area of triangle=\t %f",area);
    return 0;
    
}