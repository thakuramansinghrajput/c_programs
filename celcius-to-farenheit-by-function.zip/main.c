#include<stdio.h>
float convert(int a);

int  main()
{
    int a;
    printf("Enter the value of a\n");
    scanf("%d",&a);
    printf("The value after convert is %d",(a * 9/5) + 32);
}

float convert(int a){
    float c;
    c = (a * 9/5) + 32;
    return c;
}
    