#include<stdio.h>
int main()
{
    float raju,raghu,sheenu,akash,apple;
    raju=6;
    raghu=0.5;
    sheenu=0.5;
    akash=0.5;
    apple=raju+raghu+sheenu+akash;
    printf("the total apple raju have %f",apple);
    
    return 0;
    
}