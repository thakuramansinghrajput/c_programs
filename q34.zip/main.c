#include<stdio.h>
int main()
{
    float x,y,sum;
    x=2.9;
    y=8.7;
    sum=x+y;
    printf("the sum of float is %f",sum);
    return 0;
    
}