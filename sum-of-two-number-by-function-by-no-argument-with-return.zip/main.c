// create a function to sum the two numbers //
// by no argument with return //

#include<stdio.h>
int sum()
{
    int c,a,b;
    scanf("%d%d",&a,&b);
    c = a+b;
    return c;
}

int main()
{
    int s;
    s = sum();
    printf("%d",s);
    
    return 0;
}