#include<stdio.h>
int main()
{
int x[3][3],row,col,sum=0;
for(row = 0; row < 3; row ++)
{
    for(col = 0; col < 3; col ++)
    {
    scanf("%d",&x[row][col]);
    
}
}


for(row = 0; row < 3; row ++)
{
    for(col = 0; col < 3; col ++)
    {
    sum+=x[col][row];
    
}
}
printf("\n");

printf("%d\n",sum);


}