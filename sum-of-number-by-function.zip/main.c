#include<stdio.h>
int sum(int a , int b);

int main()
{
    int c;
    c = sum(1002,50);
    printf("The sum of a and b is %d\n",c);
    return 0;
}

int sum(int a , int b)
{
    int c;
    c = a + b;
    return c;
}