#include<stdio.h>
int main()
{
    int arr[] = {1,2,3,4,5,6,7};
    int temp, n;
    n = 7;
    
    
    
    for(int i=0; i<(n/2); i++)
    {
        temp = arr[i];
        arr[i] = arr[n-i-1];
        arr[n-i-1] = temp;
        
    }
    
    for(int i=0; i<n; i++)
    {
        printf("After reverse the %d element is %d\n", i, arr[i]);
    }
    return 0;
}