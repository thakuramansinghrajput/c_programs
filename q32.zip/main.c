#include<stdio.h>
int main()
{
    
    printf("the name is aman\n and my sir name is singh rajput");
    
}