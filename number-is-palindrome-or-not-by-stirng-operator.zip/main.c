#include<stdio.h>
#include<string.h>
int main()
{
    char x[20];
    int i, length;
    int flag = 0;
    
    puts("enter the string");
    gets(x);
    
    length = strlen(x);
    
    for(i = 0; i < length; i++)
    {
        if(x[i] != x[length-i-1])
        {
            flag = 1;
            break;
            
        }
    }
    
    if(flag) 
    {
       printf("%s is not palindrome", x);
    }
    else{
        printf("%s is  palindrome", x);
       
    }
    return 0;
}