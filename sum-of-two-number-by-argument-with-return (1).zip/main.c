// create a function to sum the two numbers //
// by argument with return //

#include<stdio.h>
int sum(int a,int b)
{
    int c;
    c = a+b;
}

int main()
{
    int x,y,s;
    printf("Enter the number\n");
    scanf("%d%d",&x,&y);
    s = sum(x,y);
    printf("%d",c);
    
    return 0;
}