#include<stdio.h>
int main()
{
    float a,b,h,area;
    a=5;
    b=8;
    h=3;
    area=0.5*(a+b)*h;
    printf("area of trapezium is %f",area);
    return 0;
    
}